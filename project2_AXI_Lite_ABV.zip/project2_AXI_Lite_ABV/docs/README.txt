AXI-Lite Professional Verification Repo

Includes:
- FSM CPU master
- RAM slave with strobes / error response
- 10+ assertions
- randomized backpressure
- scoreboard
- functional coverage
- TCL compile/run/gui/regression/report
- SimVision autoload

Run:
xrun -input scripts/run_console.tcl
xrun -input scripts/run_gui.tcl
xrun -input scripts/regression.tcl
